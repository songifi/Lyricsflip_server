export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
}
