export enum NotificationType {
  GAME_INVITE = 'game_invite',
  GAME_WON = 'game_won',
  MILESTONE = 'milestone',
}
